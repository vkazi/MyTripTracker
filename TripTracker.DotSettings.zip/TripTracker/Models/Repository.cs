using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore.Design;

namespace TripTracker.Models
{
    public class Repository
    {

        private List<Trip> Trips = new List<Trip>
        {
            new Trip
            {
                Id = 1,
                Name = "LA",
                StartDate = new DateTime(2019, 5,7),
                EndDate = new DateTime(2019, 5,7)
            },
            new Trip
            {
                Id = 2,
                Name = "London",
                StartDate = new DateTime(2019, 12 , 13),
                EndDate = new DateTime(2020, 01, 09)
            },
            new Trip
            {
                Id = 3,
                Name = "Hong Kong",
                StartDate = new DateTime(2020, 12, 21),
                EndDate =  new DateTime(9999, 12, 20)
            }
        };

        public List<Trip> Get()
        {
            return Trips;
        }
        
        public void Add(Trip newTrip)
        {
            Trips.Add(newTrip);
        }

        public void Update(Trip tripToUpdate)
        {
            Trips.Remove(Trips.First(t => t.Id == tripToUpdate.Id));
            Add(tripToUpdate);
        }

        public void Remove(int id)
        {
            Trips.Remove(item: Trips.Find(t => t.Id == id));
        }
       
    }
}